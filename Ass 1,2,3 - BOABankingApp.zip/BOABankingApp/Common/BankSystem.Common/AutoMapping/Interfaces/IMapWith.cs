﻿namespace BOABanking.Common.AutoMapping.Interfaces
{
    // Marker interface
    public interface IMapWith<TModel>
    {
    }
}