﻿namespace BOABanking.Services
{
    // Marker interface
    public interface IService
    {
    }
}