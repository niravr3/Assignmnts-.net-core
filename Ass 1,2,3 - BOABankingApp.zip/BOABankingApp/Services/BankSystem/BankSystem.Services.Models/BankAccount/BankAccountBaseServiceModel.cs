﻿namespace BOABanking.Services.Models.BankAccount
{
    using BOABanking.Models;
    using Common.AutoMapping.Interfaces;

    public abstract class BankAccountBaseServiceModel : IMapWith<BankAccount>
    {
    }
}