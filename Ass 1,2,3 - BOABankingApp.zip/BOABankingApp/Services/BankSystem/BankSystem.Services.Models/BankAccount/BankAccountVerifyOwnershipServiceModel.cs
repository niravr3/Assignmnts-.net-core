﻿namespace BOABanking.Services.Models.BankAccount
{
    public class BankAccountVerifyOwnershipServiceModel : BankAccountBaseServiceModel
    {
        public string UserId { get; set; }
    }
}