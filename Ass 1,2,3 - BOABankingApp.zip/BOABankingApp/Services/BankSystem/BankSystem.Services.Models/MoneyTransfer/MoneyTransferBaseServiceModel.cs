﻿namespace BOABanking.Services.Models.MoneyTransfer
{
    using BOABanking.Models;
    using Common.AutoMapping.Interfaces;

    public abstract class MoneyTransferBaseServiceModel : IMapWith<MoneyTransfer>
    {
    }
}