﻿namespace BOABanking.Services.Models.Card
{
    using BOABanking.Models;
    using Common.AutoMapping.Interfaces;

    public abstract class CardBaseServiceModel : IMapWith<Card>
    {
    }
}