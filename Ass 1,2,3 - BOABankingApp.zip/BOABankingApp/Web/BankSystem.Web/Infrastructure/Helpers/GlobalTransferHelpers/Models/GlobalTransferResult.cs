namespace BOABanking.Web.Infrastructure.Helpers.GlobalTransferHelpers.Models
{
    public enum GlobalTransferResult
    {
        Succeeded,
        InsufficientFunds,
        GeneralFailure
    }
}