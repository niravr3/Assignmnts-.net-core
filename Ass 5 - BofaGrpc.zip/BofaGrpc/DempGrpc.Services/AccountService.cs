﻿using DemoGrpc.Domain.Entities;
using DemoGrpc.Repository.Interfaces;
using DempGrpc.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DempGrpc.Services
{
    public class AccountService : IAccountService
    {
        public IAccountRepository _AccountRepository;

        public AccountService(IAccountRepository AccountRepository)
        {
            _AccountRepository = AccountRepository;
        }

        public Task<List<Account>> GetAsync()
        {
            //throw new Exception("error in the service");
            return _AccountRepository.GetAsync();
        }

        public Task<Account> GetByIdAsync(int AccountId)
        {
            return _AccountRepository.GetByIdAsync(AccountId);
        }

        public async Task<Account> AddAsync(Account Account)
        {
            return await _AccountRepository.AddAsync(Account);
        }
        
        public async Task<Account> UpdateAsync(Account Account)
        {
            var result = await _AccountRepository.UpdateAsync(Account);
            if (result > 0)
                return Account;

            throw new Exception("Update failed");
        }

        public async Task<bool> DeleteAsync(int AccountId)
        {
            var result = await _AccountRepository.DeleteAsync(AccountId);
            if (result > 0)
                return true;

            throw new Exception("Delete failed");
        }
    }
}