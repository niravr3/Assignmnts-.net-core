﻿using DemoGrpc.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DempGrpc.Services.Interfaces
{
    public interface IAccountService
    {
        Task<List<Account>> GetAsync();
        Task<Account> GetByIdAsync(int AccountId);
        Task<Account> AddAsync(Account Account);
        Task<Account> UpdateAsync(Account Account);
        Task<bool> DeleteAsync(int AccountId);
    }
}