﻿using AutoMapper;
using DemoGrpc.Domain.Entities;
using DemoGrpc.Protobufs;
using System.Collections.Generic;
using DemoGrpc.Protobufs.V1;

namespace DemoGrpc.Web.Mapping
{
    public class AccountProfilesV1 : Profile
    {
        public AccountProfilesV1()
        {
            CreateMap<Account, AccountReply>()
            .ForMember(dest => dest.Id, source => source.MapFrom(src => src.AccountId))
            .ForMember(dest => dest.Name, source => source.MapFrom(src => src.AccountName))
            .ForMember(dest => dest.Description, source => source.MapFrom(src => src.Description));

            CreateMap<IEnumerable<Account>, AccountsReply>()
            .ForMember(dest => dest.Accounts, source => source.MapFrom(src => src));

            CreateMap<AccountCreateRequest, Account>()
            .ForMember(dest => dest.AccountName, source => source.MapFrom(src => src.Name))
            .ForMember(dest => dest.Description, source => source.MapFrom(src => src.Description));

            CreateMap<AccountRequest, Account>()
            .ForMember(dest => dest.AccountId, source => source.MapFrom(src => src.Id))
            .ForMember(dest => dest.AccountName, source => source.MapFrom(src => src.Name))
            .ForMember(dest => dest.Description, source => source.MapFrom(src => src.Description));
        }
    }
}
