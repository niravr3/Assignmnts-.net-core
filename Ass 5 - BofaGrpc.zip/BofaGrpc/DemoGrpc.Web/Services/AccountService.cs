﻿using AutoMapper;
using DemoGrpc.Domain.Entities;
using DemoGrpc.Protobufs;
using DempGrpc.Services.Interfaces;
using Grpc.Core;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Threading.Tasks;
using DemoGrpc.Protobufs.V1;

namespace DemoGrpc.Web.Services.V1
{
    public class AccountGrpcService : AccountService.AccountServiceBase
    {
        private readonly IAccountService _AccountService;
        private readonly IMapper _mapper;

        public AccountGrpcService(IAccountService AccountService, IMapper mapper)
        {
            _AccountService = AccountService;
            _mapper = mapper;
        }

        public override async Task GetAllStreamed(EmptyRequest request, IServerStreamWriter<AccountReply> responseStream, ServerCallContext context)
        {
            var headers = context.GetHttpContext().Request.Headers;
            var lst = await _AccountService.GetAsync();

            foreach (var Account in lst)
            {
                await responseStream.WriteAsync(_mapper.Map<AccountReply>(Account));
            }
            await Task.CompletedTask;
        }

        //[Authorize]
        public override async Task<AccountsReply> GetAll(EmptyRequest request, ServerCallContext context)
        {
            //throw new RpcException(new Status(StatusCode.Internal, "Internal error"), "Internal error occured");
            var Accounts = await _AccountService.GetAsync();
            return _mapper.Map<AccountsReply>(Accounts);
        }

        //[Authorize]
        public override async Task<AccountReply> GetById(AccountSearchRequest request, ServerCallContext context)
        {
            var Account = await _AccountService.GetByIdAsync(request.AccountId);
            return _mapper.Map<AccountReply>(Account);
        }

        //[Authorize]
        public override async Task<AccountReply> Create(AccountCreateRequest request, ServerCallContext context)
        {
            //var currentUser = context.GetHttpContext().User;
            //throw new RpcException(new Status(StatusCode.InvalidArgument,"test"), "test");
            var createAccount = _mapper.Map<Account>(request);
            var Account = await _AccountService.AddAsync(createAccount);
            return _mapper.Map<AccountReply>(Account);
        }

        //[Authorize]
        public override async Task<AccountReply> Update(AccountRequest request, ServerCallContext context)
        {
            //var currentUser = context.GetHttpContext().User;
            var updateAccount = _mapper.Map<Account>(request);
            var Account = await _AccountService.UpdateAsync(updateAccount);
            return _mapper.Map<AccountReply>(Account);
        }

        //[Authorize]
        public override async Task<EmptyReply> Delete(AccountSearchRequest request, ServerCallContext context)
        {
            //var currentUser = context.GetHttpContext().User;
            await _AccountService.DeleteAsync(request.AccountId);
            return new EmptyReply();
        }
    }
}