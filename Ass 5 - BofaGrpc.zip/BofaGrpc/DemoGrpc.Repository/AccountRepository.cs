﻿using DemoGrpc.Domain.Entities;
using DemoGrpc.Repository.Database;
using DemoGrpc.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoGrpc.Repository
{
    public class EFAccountRepository : IAccountRepository
    {
        private readonly DemoDbContext _dbContext;
        public EFAccountRepository(DemoDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<List<Account>> GetAsync()
        {
            return await _dbContext.Account.AsNoTracking().ToListAsync();
        }

        public async Task<Account> GetByIdAsync(int AccountId)
        {
            return await _dbContext.Account.AsNoTracking().FirstOrDefaultAsync(x => x.AccountId == AccountId);
        }

        public async Task<Account> AddAsync(Account Account)
        {
            _dbContext.Add(Account);
            await _dbContext.SaveChangesAsync();
            return Account;
        }

        public async Task<int> UpdateAsync(Account Account)
        {
            var AccountToUpdate = await _dbContext.Account
                                                    .Where(x => x.AccountId == Account.AccountId)
                                                    .FirstOrDefaultAsync();

            AccountToUpdate.AccountName = Account.AccountName;
            AccountToUpdate.Description = Account.Description;

            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int AccountId)
        {
            var AccountToDelete = await _dbContext.Account
                                                    .Where(x => x.AccountId == AccountId)
                                                    .FirstOrDefaultAsync();

            _dbContext.Remove(AccountToDelete);
            return await _dbContext.SaveChangesAsync();
        }
    }
}