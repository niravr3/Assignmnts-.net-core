﻿using DemoGrpc.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DemoGrpc.Repository.Interfaces
{
    public interface IAccountRepository
    {
        Task<List<Account>> GetAsync();
        Task<Account> GetByIdAsync(int AccountId);
        Task<Account> AddAsync(Account Account);
        Task<int> UpdateAsync(Account Account);
        Task<int> DeleteAsync(int AccountId);
    }
}