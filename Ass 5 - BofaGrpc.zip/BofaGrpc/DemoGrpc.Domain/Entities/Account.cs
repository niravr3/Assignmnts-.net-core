﻿namespace DemoGrpc.Domain.Entities
{
    public class Account
    {
        public int AccountId { get; set; }
        public string AccountName { get; set; }
        public string Description { get; set; }
    }
}